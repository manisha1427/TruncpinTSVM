function [accPinDual]= pin_transductive_svms_real(S)
for l=1:5
[ro,p]= size(S);
for j=1:p-1
   S(:,j) = (S(:,j) - min(S(:,j))) / ( max(S(:,j)) - min(S(:,j)));
end
%Splitting the data set into Training set and Test set
p=p-1;
nu= randperm(ro);
n= round(ro*0.55);
Xtrain = S(nu(1:n),1:end-1);
Xtest=S(nu(n+1:ro),1:end-1);
TrainY=S(nu(1:n),end);
ytest=S(nu(n+1:ro),end);

Xtrain=Xtrain';
Xtest=Xtest';
TrainY=TrainY';
ytest=ytest';
%Adding outliers in the dataset
Xtrainper = Xtrain;
noise = 0.30;
for i=1:n*noise
    if(TrainY(i)==1)
        TrainY(i)=-1;
    else
        TrainY(i)=1;
    end
end
XX=[Xtrainper Xtest];
%XX=[Xtrain Xtest];
yy=[TrainY -2*ones(1,(ro-n))];

%[W0,b0,stat] = svmocas(XX(:,1:100),1,yy(1:100),svmC,1,0.003);
% SVM method
time_svm=tic;
size(Xtrainper')
size(TrainY')
% model=fitcsvm(Xtrainper',TrainY');% libsvm
% time_elapsed_svm=toc(time_svm);
% Label=model.ClassNames;
% SVs=model.SupportVectors;
% 
% if Label(1)==1
%     W0=SVs'*model.Alpha;
%     b0=-model.rho;
% else
%     W0=-model.SVs'*model.sv_coef;
%     b0=model.rho;
% end

model=svmtrain(TrainY', Xtrainper','-s 0 -t 0'); % libsvm
time_elapsed_svm=toc(time_svm);
if model.Label(1)==1,
    W0=model.SVs'*model.sv_coef;
    b0=-model.rho;
else
    W0=-model.SVs'*model.sv_coef;
    b0=model.rho;
end
%W0=[1 1]';

% TSVM-CCCP

time_pin=tic;
[w3 b3] = train_linear_pin_svm_sg_robust(XX,yy,1,0.1,W0,b0,0.1); % proposed method
timeElapsed_pin(l)=toc(time_pin);
time_dual_pin=tic;
[w4 b4] = train_linear_pin_svm_robust_dual(XX,yy,1,0.1,W0,b0);
timeElapsed_pin_dual(l)=toc(time_dual_pin);

% hyperplane.w=w4;
% hyperplane.b=b4;
% rtsvm_models{i} = hyperplane;
% nbclass = length(svm_models);
% n=size(test_features,2);
% 
% for i=1:nbclass,
%     svm_model=svm_models{i};
%     [score1]=test_features'*svm_model.w+svm_model.b;
%     scores_all(i,:)=score1;
% end
% 
% for i=1:n,
%     [val ypred(i)]=max(scores_all(:,i));
% end
% 
% dif=ypred-test_labels;
% ll=find(abs(dif)>=0.5);
% misclassifications=length(ll);
% accuracy=(length(test_labels)-misclassifications)/length(test_labels);


% TSVM_LDS
% Xl = XX(:,1:100);  
% Xu = XX(:,101:end);
% Yl = yy(1:100)';
% Yu = yy(1:100)';
% opt.C = 0.1; % 
% rho = 1;     
% Yp = lds_embedding(Xl,Xu,Yl,rho,opt); 
%   
% err2 = mean( Yp.*Yu < 0 );

% Accuracies
%ytest=[ones(1,50) -ones(1,50)];

scores4=((XX'*w3) + b3);
y4=sign(scores4);
scores5 = ((XX'*w4) + b4);
y5=sign(scores5);


RR4=length(find(y4(n+1:ro)==ytest'));
RR5=length(find(y5(n+1:ro)==ytest'));



acc_pin(l) = RR4/length(ytest);

acc_pin_dual(l)=RR5/length(ytest);


end
acc_svm
fprintf('SVM')
accSVM = mean(acc_svm)
std(acc_svm)
timeSVM=mean(time_elapsed_svm)

fprintf('pin-TSVM-SG')
accPin= mean(acc_pin)
std(acc_pin)
timePin=mean(timeElapsed_pin)

fprintf('pin-TSVM-dual')
accPinDual= mean(acc_pin_dual)
std(acc_pin_dual)
timePinDual=mean(timeElapsed_pin_dual)

end

%RR4=100-(err2*100)


