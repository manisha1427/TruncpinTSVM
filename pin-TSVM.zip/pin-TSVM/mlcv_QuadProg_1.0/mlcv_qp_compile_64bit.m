% This script compiles Matlab's MEX interfaces for LIBQP solvers.
%

mex -largeArrayDims mlcv_qp_gsmo_mex.c mlcv_qp_gsmo.cpp

